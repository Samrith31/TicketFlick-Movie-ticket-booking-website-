
    <div class="container1">
      
      <div id="item1">
        <a href="Movieslist.php" class="citiesLinkList" target="_blank"><img src="images/bangalore.jpg" width="100%"></a>
        <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Bangalore</a></div>
      </div>

      <div id="item1">
        <a href="Movieslist.php" class="citiesLinkList" target="_blank"><img src="images/chennai.jpg" width="100%"></a>
        <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Chennai</a></div>
      </div>
      
      </div>
      
     
     
      <div class="container2">
      
        <div id="item1">
          <a href="Movieslist.php" class="citiesLinkList" target="_blank"><img src="images/mumbai.jpg" width="100%"></a>
          <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Mumbai</a></div>
        </div>
  
        <div id="item1">
          <a href="Movieslist.php" class="citiesLinkList" target="_blank"><img src="images/delhi.jpg" width="100%"></a>
          <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Delhi</a></div>
        </div>
        
        </div>
        

        <div class="container3">
      
          <div id="item1">
            <a href="Movieslist.php" class="citiesLinkList"><img src="images/kolkata.jpg" width="100%"></a>
            <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Kolkata</a></div>
          </div>
    
          <div id="item1">
            <a href="Movieslist.php" class="citiesLinkList"><img src="images/hyderbad.jpg" width="100%"></a>
            <div> <a href="Movieslist.php" class="nameofcitiesLinkList" target="_blank">Hyderbad</a></div>
          </div>
          
          </div>
          



