




function butclick(){
if(confirm(`Are you Sure to book the tickets `)){
         location.href="payment.php";
};

}