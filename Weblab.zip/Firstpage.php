<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TicketFlick</title>


<style>
.firstpart{
    
    height: 600px;
}
.firstpart::before{
    content: "";
    position: absolute;
    background: url(images/movieback.jpg);
    top:0px;
    left: 0px;
    z-index: -1;
    opacity: 0.9;
    width: 100%;
    height: 600px;
    

}

.moviescontainer1{
    display: flex;
    text-align: center;
}

#item2{
    margin-right: 30px;
}
.nameofmovies{
        font-size: 2.5rem;
        text-decoration: none;
       color: #e50914;
      }
      .nameofmovies:hover{
        text-decoration: underline;
        color :white;
      }

 .MainHead{
    margin-top: 10px;
    text-align: center;
    font-size: 2.5rem;
    color:#f1bc48;
     font-weight: 100px;
 }
 .secondpart{
    display: flex;
    flex-direction: column;
    margin-top: 8px;
    background-color: black;
    justify-content: center;
    align-items: center;
   
 }
 .secondfirst{
    display: flex;
 }
 #titleSecond{
    display: flex;
    font-size: 35px;
    padding:15px 20px;
    margin-left: 50px;

}
#titleSecond img{
    width: 70px;
    height: 60px;
}
#titleSecond div{
    font-size: 2.3rem;
    color:white;
}
.text{
    padding: 15px 100px 39px 44px;
    font-size: 2.3rem;
}
.thirdpart{
    display: flex;
    border-radius: 3px solid red;
    margin-top: 8px;
}
.head{
    display: flex;
    flex-direction: column;
}
.selectcities{
    margin-top: 5px;
}
.selectcitiesbut{
     width: 350px;
     height: 60px;
     background: #e50914;
     border-radius: 30px;
     margin-bottom: 30px;
}


</style>







</head>
<body>


<div class="firstpart">

    
<nav id="navbar1">
    <div id="title">
        <div>Ticket</div>
        <img src="images/logo.ico">
        <div>Flick</div>
    </div>
    <div id="search">
        <input type="text" name="search" size="30" id="search" placeholder="  Search Movies" ></div>
        
        <div id="but" >
        <button id="btn"><a href="Signupform.php" target="_blank" style="text-decoration: none; color:white; font-size: 1.2rem;">Login</a></button>
        </div>
</nav>


<nav class="navbar2">

    <u1>
        <li class="item"> <a href="#">Home</a></li>
        <li class="item"> <a href="#">Movies</a></li>
        <li class="item"> <a href="login.php">Login</a></li>
        <li class="item"> <a href="#">Contact Us</a></li>
    </u1>
    
        
    </nav>


    <div class="trendingmovies">


        <h2 class="MainHead">Trending Movies</h2>
<marquee onMouseover="stop()" onMouseout="start()" Scrollamount=10>
    <div class="moviescontainer1">


        <div id="item2">
            <a href="Selectcities.html" target="_blank" class="moviesLinkList"><img src="images/ranjana.jpg" width="400px" height="340px"></a>
            <div> <a href="Selectcities.html" target="_blank" class="nameofmovies">Raanjhana</a></div>
          </div>

    <div id="item2">
        <a href="Selectcities.html" target="_blank" class="moviesLinkList"><img src="images/the notebook.jpg" width="400px" height="340px"></a>
        <div> <a href="Selectcities.html" target="_blank" class="nameofmovies">The Notebook</a></div>
      </div>

      <div id="item2">
        <a href="Selectcities.html" target="_blank" class="moviesLinkList"><img src="images/love,rosie.jpg"  width="400px" height="340px"></a>
        <div> <a href="Selectcities.html" target="_blank" class="nameofmovies">Love,Rosie</a></div>
      </div>
      
   
        <div id="item2">
          <a href="Selectcities.html" target="_blank" class="moviesLinkList"><img src="images/About_Time_(2013_film)_Poster.jpg"  width="400px" height="340px"></a>
          <div> <a href="Selectcities.html" target="_blank`" class="nameofmovies">About Time</a></div>
        </div>
  
    </div>
</marquee>
    </div>





</div>


<div class="secondpart">
    <div class="secondfirst">
    <div class="text">
       Book.. Tickets.. AnyTime.. Anywhere..!
    </div>
    <div id="titleSecond">
        <div>Ticket</div>
        <img src="images/logo.ico">
        <div>Flick</div>
    </div>
    </div>

     <div class="selectcities">
        <button class="selectcitiesbut"><a href="Selectcities.html"  target="_blank" style="text-decoration: none; color: white; font-size: 1.8rem;">Select Cities</a></button>
     </div>



</div>





<link rel="stylesheet" href="style.css" >  
</body>
</html>